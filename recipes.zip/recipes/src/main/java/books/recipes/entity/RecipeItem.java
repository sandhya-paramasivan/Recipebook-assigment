package books.recipes.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="RECIPEITEM")
public class RecipeItem {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private Integer id;
	
	@Column
	private String name;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdOn;
	
	@Column
	private boolean vegetarian;
	
	public String getIngredients() {
		return ingredients;
	}
	public void setIngredients(String ingredients) {
		this.ingredients = ingredients;
	}
	@Column(name="noof_servings")
	private Integer noofServings;
	
	@Lob
	@Column(name="ingredients", length=500,nullable=false,unique=false)
	private String ingredients;
	
	@Transient
	private List<String> ingredientsList;
	
	@Column(name="cooking_instruction", length=500,nullable=false,unique=false)
	@Lob
	private String cookingInstruction;
	
	public String getCookingInstruction() {
		return cookingInstruction;
	}
	public void setCookingInstruction(String cookingInstruction) {
		this.cookingInstruction = cookingInstruction;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public boolean isVegetarian() {
		return vegetarian;
	}
	public void setVegetarian(boolean vegetarian) {
		this.vegetarian = vegetarian;
	}
	public Integer getNoofServings() {
		return noofServings;
	}
	public void setNoofServings(Integer noofServings) {
		this.noofServings = noofServings;
	}
	public List<String> getIngredientsList() {
		return ingredientsList;
	}
	public void setIngredientsList(List<String> ingredientsList) {
		this.ingredientsList = ingredientsList;
	}
	
	

}

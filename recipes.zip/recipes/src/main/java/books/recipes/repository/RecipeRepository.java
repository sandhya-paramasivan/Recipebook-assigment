package books.recipes.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import books.recipes.entity.RecipeItem;

@Repository
public interface RecipeRepository extends JpaRepository<RecipeItem, Integer>{
	
	
	/*Need to enhance this part of code using pagination*/
	@Query("select r from RecipeItem r where r.ingredients is not null")
	public List<RecipeItem> fetchAllRecipes();
	
}

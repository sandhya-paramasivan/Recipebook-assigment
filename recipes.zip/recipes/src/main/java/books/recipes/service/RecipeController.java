package books.recipes.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import books.recipes.entity.RecipeItem;
import io.swagger.annotations.Api;

@RestController
@Api(value="List of API's which has CRUD operations for managing recipe book")
@ControllerAdvice
public class RecipeController {

	@Autowired
	private RecipeService recipeService;
	
	@RequestMapping(value ="/myrecipes/add", method=RequestMethod.POST,  consumes = MediaType.APPLICATION_JSON_VALUE, 
            produces = MediaType.APPLICATION_JSON_VALUE)
	public RecipeItem addRecipe(@RequestBody RecipeItem item)
	{
		return recipeService.addRecipe(item);
	}
	
	@RequestMapping(value ="/myrecipes/fetch/{id}", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public RecipeItem getRecipe(@PathVariable Integer id)
	{
		return recipeService.fetchRecipe(id);
	}
	
	@RequestMapping(value ="/myrecipes/update", method=RequestMethod.PUT,   consumes = MediaType.APPLICATION_JSON_VALUE, 
            produces = MediaType.APPLICATION_JSON_VALUE)
	public RecipeItem updateRecipe(@RequestBody RecipeItem item)
	{
		return recipeService.updateRecipe(item);
	}
	
	@RequestMapping(value ="/recipes", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<RecipeItem> getAllRecipe()
	{
		return recipeService.fetchAllRecipe();
	}
	
	@RequestMapping(value="/myrecipes/delete/{id}", method=RequestMethod.DELETE)
	public String deleteRecipe(@PathVariable Integer id)
	{
		try {
			this.recipeService.deleteRecipe(id);
			return "Recipe Deleted successfully";
		} catch (Exception e) {
			return "Exception in deleting the recipe";
		}

	}
	
}

package books.recipes.service;


import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import books.recipes.entity.RecipeItem;
import books.recipes.repository.RecipeRepository;

@Service
@Transactional
public class RecipeService {
	
    Logger log = LoggerFactory.getLogger(RecipeService.class);

	
	@Autowired
	public RecipeRepository recipeRepository;
	
	public RecipeItem addRecipe(RecipeItem item) {
		mapIngredientsList(item);
		return recipeRepository.save(item);
	}
	
	public RecipeItem updateRecipe(RecipeItem item) {
		mapIngredientsList(item);
		return recipeRepository.save(item);
	}
	

	public RecipeItem fetchRecipe(Integer id) {
		log.info("Fetching recipe for the id " + id);
		Optional<RecipeItem> recipeItem =recipeRepository.findById(id);
		if(recipeItem.isPresent()) {
			mapIngredientsList(recipeItem.get());
			return recipeItem.get();
		}
		
		return null;
	}

	public List<RecipeItem> fetchAllRecipe() {
		List<RecipeItem>  recipes=recipeRepository.fetchAllRecipes();
		if(recipes != null && !recipes.isEmpty()) {
			recipes.forEach(r-> mapIngredientsList(r));
		}
		return recipes;
	}

	private void mapIngredientsList(RecipeItem item) {
		if(item.getIngredients() != null) {
			List<String> ingredientslist = Arrays.asList(item.getIngredients().split(","));	
			item.setIngredientsList(ingredientslist);
		}
	}
	
	public void deleteRecipe(Integer id) {
		 recipeRepository.deleteById(id);
	}
}
